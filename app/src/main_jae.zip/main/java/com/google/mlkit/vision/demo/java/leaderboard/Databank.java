package com.google.mlkit.vision.demo.java.leaderboard;

public class Databank {
}
